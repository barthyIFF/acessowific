package goaccess

class Ajax {

    static constraints = {
    }
}
