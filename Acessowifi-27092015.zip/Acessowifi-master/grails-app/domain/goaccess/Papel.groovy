package goaccess

class Papel implements Serializable {

	private static final long serialVersionUID = 1

	String authority

	Papel(String authority) {
		this()
		this.authority = authority
	}

	@Override
	int hashCode() {
		authority?.hashCode() ?: 0
	}

	@Override
	boolean equals(other) {
		is(other) || (other instanceof Papel && other.authority == authority)
	}

	@Override
	String toString() {
		authority
	}

	static constraints = {
		authority unique: true
	}

	static mapping = {
		cache true
	}
}
